
function calc(){
 const e=parseInt(document.getElementById('engine').value);
 const p=parseInt(document.getElementById('parts').value);
 document.getElementById('quote').innerText='Estimated Price: $'+(e+p).toLocaleString();
}
